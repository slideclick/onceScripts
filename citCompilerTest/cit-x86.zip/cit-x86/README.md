# cit
基于x86体系结构的类C编译系统

## 构建
1. `./do`
2. 生成可执行文件`./cit`

## 运行
1. 命令格式`./cit -h` 
2. 编译`./cit ./file/test.c test`
3. 生成可执行文件`./work/test`
4. 测试运行`./work/test`

